/* global React, ReactDOM, DesignCanvas, DCSection, DCArtboard,
          DocFrame, PreviewWord, PreviewSlides, PreviewSheet */

const ARTBOARD_W = 1280;
const ARTBOARD_H = 840;

function App() {
  return (
    <DesignCanvas>
      <DCSection
        id="office-previews"
        title="Office document previews"
        subtitle="How Tomorrowland renders Word, PowerPoint and Excel files in the viewer. Dark-first, flat surfaces — no skeuomorphic white sheets, no Office chrome."
      >
        <DCArtboard
          id="docx"
          label="Word · .docx — html mode"
          width={ARTBOARD_W}
          height={ARTBOARD_H}
        >
          <DocFrame kind="docx">
            <PreviewWord />
          </DocFrame>
        </DCArtboard>

        <DCArtboard
          id="pptx"
          label="PowerPoint · .pptx — slides mode"
          width={ARTBOARD_W}
          height={ARTBOARD_H}
        >
          <DocFrame kind="pptx">
            <PreviewSlides />
          </DocFrame>
        </DCArtboard>

        <DCArtboard
          id="xlsx"
          label="Excel · .xlsx — table mode"
          width={ARTBOARD_W}
          height={ARTBOARD_H}
        >
          <DocFrame kind="xlsx">
            <PreviewSheet />
          </DocFrame>
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
