/* global React */
// Word (.docx / .odt) — html preview mode.
// Long-form reading: H2 sections, paragraphs, lists, an inline table,
// a callout, an inline code reference. Page rail on the left, page
// indicator + word count at the bottom. Flat dark surface — no white sheet.

function PreviewWord() {
  return (
    <div className="pv-word">
      <div className="pv-word-scroll">
        <aside className="pv-word-rail" aria-hidden="true">
          <span>1</span>
          <span>2</span>
          <span className="rail-active">3</span>
          <span>4</span>
          <span>5</span>
          <span>6</span>
          <span className="rail-line">·</span>
          <span>12</span>
        </aside>

        <article className="pv-word-article">
          <h2>3 · Pre-checks</h2>
          <p>
            Before opening a vendor onboarding request, confirm the requestor sits in an
            authorised cost-centre and that the vendor does not already exist in NetSuite.
            Duplicate vendor records are the single largest cause of failed PO sync — there
            is no automated dedup on the NetSuite side, only at the gateway.
          </p>
          <p>
            Use the gateway probe rather than the NetSuite UI for existence checks. The UI
            search ignores trailing whitespace; the probe does not.
          </p>
          <pre style={{
            background: 'var(--color-surface)',
            border: '1px solid var(--color-border)',
            borderRadius: 6,
            padding: '10px 14px',
            margin: '0 0 18px',
            fontFamily: 'var(--font-family-mono)',
            fontSize: 12.5,
            color: 'var(--color-text-primary)',
            overflowX: 'auto',
          }}>
            <code style={{ background: 'transparent', padding: 0, color: 'inherit' }}>
{`$ tl-gateway vendor probe --tax-id "DE284157653"
  matched: 0   exact: 0   fuzzy: 1
  fuzzy:   "Stadtwerke Köln GmbH" (id=v-184211)`}
            </code>
          </pre>

          <div className="pv-word-callout">
            <span className="cw-tag">Caution</span>
            <span>
              <strong>Never</strong> bypass the probe even when the requestor is certain the
              vendor is new. The fuzzy match exists for a reason. If it returns a candidate,
              page <code>finance-ops</code> before continuing.
            </span>
          </div>

          <h2>4 · Approval flow</h2>
          <p>
            All POs above €25,000 require dual sign-off. The first signer is the
            cost-centre owner, drawn from the <code>finance-ops-approvers</code> AD group;
            the second is a finance controller. Auto-routing uses the table below.
          </p>

          <table className="pv-word-table">
            <thead>
              <tr>
                <th style={{ width: '32%' }}>Threshold</th>
                <th>First signer</th>
                <th>Second signer</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="mono">≤ €5,000</td>
                <td>Cost-centre owner</td>
                <td>—</td>
              </tr>
              <tr>
                <td className="mono">€5,001 – €25,000</td>
                <td>Cost-centre owner</td>
                <td>Department head</td>
              </tr>
              <tr>
                <td className="mono">€25,001 – €100,000</td>
                <td>Department head</td>
                <td>Finance controller</td>
              </tr>
              <tr>
                <td className="mono">&gt; €100,000</td>
                <td>Department head</td>
                <td>CFO</td>
              </tr>
            </tbody>
          </table>

          <h2>5 · Rollback</h2>
          <p>
            Rollback covers the window between PO creation in Coupa and successful sync to
            NetSuite. If the sync worker fails three times in succession, the PO is moved
            to the dead-letter queue and the requestor is notified by email.
          </p>
          <ol>
            <li>Open the failed event in the admin DLQ view.</li>
            <li>Confirm the failure mode is <em>not</em> a NetSuite outage (check the status page).</li>
            <li>Retry from the DLQ. If it fails a fourth time, escalate.</li>
            <li>Document the resolution in the PO comment thread.</li>
          </ol>

          <h2>6 · Escalation</h2>
          <p>
            Out-of-hours escalation goes to the on-call pager via PagerDuty. The on-call
            rota is published one week ahead and lives in the <a href="#">PO escalation
            rota — Q3</a> page.
          </p>
        </article>
      </div>

      <footer className="pv-word-footer">
        <div className="pages">
          <button className="nav-btn">‹</button>
          <span>Page <b>3</b> of 12</span>
          <button className="nav-btn">›</button>
        </div>
        <div>2,418 words · last edit by K. Tanaka, 6d ago</div>
      </footer>
    </div>
  );
}

window.PreviewWord = PreviewWord;
