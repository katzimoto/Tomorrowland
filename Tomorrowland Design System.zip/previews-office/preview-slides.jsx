/* global React */
// PowerPoint (.pptx) — slides preview mode.
// Vertical filmstrip rail of thumbnails (slide index + title)
// Main slide canvas, 16:9, dark card with the slide's actual content
// Speaker notes drawer pinned to the bottom

const SLIDES = [
  { i: 1, label: 'Title', kind: 'title' },
  { i: 2, label: 'Agenda', kind: 'agenda' },
  { i: 3, label: 'Section · Performance', kind: 'section' },
  { i: 4, label: 'Ingestion throughput', kind: 'active' },
  { i: 5, label: 'Search latency p95', kind: 'chart' },
  { i: 6, label: 'Q&A volume', kind: 'chart' },
  { i: 7, label: 'Section · Risks', kind: 'section' },
  { i: 8, label: 'LibreTranslate p99', kind: 'text' },
  { i: 9, label: 'Confluence DC migration', kind: 'text' },
  { i: 10, label: 'Section · FY26 plan', kind: 'section' },
  { i: 11, label: 'Hiring — intelligence', kind: 'text' },
  { i: 12, label: 'Roadmap timeline', kind: 'timeline' },
];

function Thumb({ slide, active }) {
  return (
    <button className={`pv-thumb${active ? ' active' : ''}`}>
      <div className={`pv-thumb-card${slide.kind === 'section' ? ' section' : ''}`}>
        <div className="t-title">{slide.label}</div>
        {slide.kind !== 'section' && (
          <>
            <div className="t-lines">
              <div className="t-line"></div>
              <div className="t-line s2"></div>
              <div className="t-line s3"></div>
            </div>
            <div className="t-block"></div>
          </>
        )}
      </div>
      <div className="pv-thumb-meta">
        <span className="num">{String(slide.i).padStart(2, '0')}</span>
      </div>
    </button>
  );
}

function PreviewSlides() {
  return (
    <div className="pv-slides">
      <aside className="pv-slides-rail">
        <div className="pv-slides-rail-header">Slides · 18</div>
        <div className="pv-slides-rail-list">
          {SLIDES.map((s) => (
            <Thumb key={s.i} slide={s} active={s.i === 4} />
          ))}
        </div>
      </aside>

      <section className="pv-slides-stage">
        <div className="pv-stage-bar">
          <span className="pos">
            Slide <b>04</b> of 18
          </span>
          <div className="ctrls">
            <button className="ctrl-btn">‹ Previous</button>
            <button className="ctrl-btn">Next ›</button>
            <span style={{ width: 12 }}></span>
            <button className="ctrl-btn">100%</button>
          </div>
        </div>

        <div className="pv-stage-canvas">
          <div className="pv-slide">
            <div className="pv-slide-eyebrow">02 · Performance</div>
            <h2 className="pv-slide-title">Ingestion throughput is up 38% quarter‑over‑quarter.</h2>
            <div className="pv-slide-body">
              <div className="pv-slide-stats">
                <div className="pv-slide-stat ok">
                  <div className="v">2.41M</div>
                  <div className="l">Docs indexed</div>
                </div>
                <div className="pv-slide-stat">
                  <div className="v">+38%</div>
                  <div className="l">vs Q2</div>
                </div>
                <div className="pv-slide-stat warn">
                  <div className="v">4.8s</div>
                  <div className="l">p95 ingestion</div>
                </div>
                <div className="pv-slide-stat">
                  <div className="v">99.7%</div>
                  <div className="l">DLQ recovery</div>
                </div>
              </div>
              <ul className="pv-slide-bullets" style={{ marginTop: 18 }}>
                <li><strong>Worker‑fast</strong> batch size raised 32 → 64; no Elastic back‑pressure observed.</li>
                <li><strong>OCR fallback</strong> rolled out to all PDF sources — scanned legal share now searchable.</li>
                <li>Still missing the 5 s ingestion target on Confluence attachments &gt; 12 MB.</li>
              </ul>
            </div>
            <div className="pv-slide-corner">
              <span>Tomorrowland</span>
              <span className="dot">·</span>
              <span>Q3 2025</span>
              <span className="dot">·</span>
              <span>04 / 18</span>
            </div>
          </div>
        </div>

        <div className="pv-stage-notes">
          <div className="label">Speaker notes</div>
          <div className="body">
            Lead with the headline — 38% is the largest single‑quarter jump we've seen since launch. Credit the
            batch‑size change first; OCR is the more durable win but harder to demo. If the room presses on the
            p95 number, acknowledge the 4.8 s figure breaches our 5 s target — we land the explanation on slide 5.
            Do <em>not</em> spend more than 90 seconds here.
          </div>
        </div>
      </section>
    </div>
  );
}

window.PreviewSlides = PreviewSlides;
