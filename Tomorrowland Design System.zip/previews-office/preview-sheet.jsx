/* global React */
// Excel (.xlsx) / CSV — table preview mode.
// Spreadsheet grid: column letters across the top, row numbers down the left,
// frozen header row, monospace numerics right-aligned, sheet tabs at bottom.

const COLS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

const ROWS = [
  { source: 'SMB-finance', type: 'folder',     docs: 18_412, lang: 'de',    sync: '2025-08-14 03:14', size: '4.2 GB', status: 'ok' },
  { source: 'SMB-legal',   type: 'folder',     docs: 9_204,  lang: 'de, en', sync: '2025-08-14 03:18', size: '1.8 GB', status: 'ok' },
  { source: 'SMB-hr',      type: 'folder',     docs: 1_104,  lang: 'en',    sync: '2025-08-14 03:21', size: '184 MB', status: 'ok' },
  { source: 'wiki.internal', type: 'confluence', docs: 41_088, lang: 'en',   sync: '2025-08-14 02:00', size: '—',      status: 'ok' },
  { source: 'wiki.legal',  type: 'confluence', docs: 8_402,  lang: 'de, en', sync: '2025-08-14 02:00', size: '—',      status: 'warn' },
  { source: 'jira.eng',    type: 'jira',       docs: 22_915, lang: 'en',    sync: '2025-08-14 02:00', size: '—',      status: 'ok' },
  { source: 'jira.infra',  type: 'jira',       docs: 7_481,  lang: 'en',    sync: '2025-08-14 02:00', size: '—',      status: 'err' },
  { source: 'mail.archive-2024', type: 'folder', docs: 184_021, lang: 'mixed', sync: '2025-08-12 19:42', size: '38.1 GB', status: 'ok' },
  { source: 'nifi.flow-vendor', type: 'nifi',  docs: 612,    lang: 'en',    sync: '2025-08-14 04:01', size: '—',      status: 'ok' },
  { source: 'nifi.flow-legal',  type: 'nifi', docs: 2_104,  lang: 'de',    sync: '2025-08-13 22:18', size: '—',      status: 'warn' },
  { source: 'inbound.kafka.partner-a', type: 'nifi', docs: 9_812, lang: 'en', sync: '2025-08-14 04:02', size: '—',    status: 'ok' },
  { source: 'archive-2021',    type: 'folder', docs: 64_902, lang: 'de',    sync: '2025-08-11 02:14', size: '24.8 GB', status: 'ok' },
  { source: 'archive-2022',    type: 'folder', docs: 71_148, lang: 'de',    sync: '2025-08-11 02:55', size: '27.4 GB', status: 'ok' },
  { source: 'archive-2023',    type: 'folder', docs: 88_204, lang: 'mixed', sync: '2025-08-11 03:41', size: '32.0 GB', status: 'ok' },
  { source: 'photo-share',     type: 'folder', docs: 14_810, lang: '—',     sync: '2025-08-10 02:14', size: '12.1 GB', status: 'warn' },
];

const STATUS_PILL = {
  ok:   { cls: 'ok',   label: 'Active' },
  warn: { cls: 'warn', label: 'Paused' },
  err:  { cls: 'err',  label: 'Failed' },
};

function PreviewSheet() {
  // Active cell: row 5, column C (Documents) — used to drive the formula bar
  const activeRow = 5;
  const activeCol = 3; // 1-based among data columns (A is rownum, B=Source, C=Type, D=Documents)
  const selectedLetter = 'D'; // Documents column letter in the grid display

  return (
    <div className="pv-sheet">
      <div className="pv-sheet-bar">
        <div className="name-box">D6</div>
        <span className="fx">ƒx</span>
        <div className="formula">
          <span className="op">=</span>SUMIF(<span className="id">type_col</span>,<span className="op"> </span>"confluence",<span className="op"> </span><span className="id">docs_col</span>)
          <span style={{ color: 'var(--color-text-muted)', marginLeft: 12 }}>→ <span className="num">49,490</span></span>
        </div>
      </div>

      <div className="pv-sheet-grid">
        <table className="pv-sheet-table">
          <thead>
            <tr className="col-letters">
              <th className="corner">·</th>
              {COLS.map((c) => (
                <th key={c} className={c === selectedLetter ? 'sel' : ''}>{c}</th>
              ))}
            </tr>
            <tr className="header-row" style={{ display: 'table-row' }}>
              <th className="rownum">1</th>
              <th style={{ width: '22%' }}>Source</th>
              <th style={{ width: '12%' }}>Type</th>
              <th style={{ width: '12%' }}>Documents</th>
              <th style={{ width: '10%' }}>Language</th>
              <th style={{ width: '16%' }}>Last sync</th>
              <th style={{ width: '10%' }}>Size</th>
              <th style={{ width: '12%' }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {ROWS.map((r, i) => {
              const rownum = i + 2; // header is row 1
              const pill = STATUS_PILL[r.status];
              const isActiveRow = rownum === activeRow + 1;
              return (
                <tr key={r.source}>
                  <td className={`rownum${isActiveRow ? ' sel' : ''}`}>{rownum}</td>
                  <td>{r.source}</td>
                  <td className="muted">{r.type}</td>
                  <td className={`num${isActiveRow ? ' active' : ''}`}>
                    {r.docs.toLocaleString('en-US')}
                  </td>
                  <td className="muted">{r.lang}</td>
                  <td className="muted" style={{ fontFamily: 'var(--font-family-mono)', fontSize: 12 }}>
                    {r.sync}
                  </td>
                  <td className="num muted">{r.size}</td>
                  <td>
                    <span className={`pill ${pill.cls}`}>{pill.label}</span>
                  </td>
                </tr>
              );
            })}
            {/* A few empty trailing rows for the spreadsheet feel */}
            {[0, 1, 2, 3].map((j) => (
              <tr key={`pad-${j}`}>
                <td className="rownum">{ROWS.length + 2 + j}</td>
                <td></td><td></td><td></td><td></td><td></td><td></td><td></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="pv-sheet-tabs">
        <button className="pv-sheet-tab active"><span className="swatch"></span>Sources</button>
        <button className="pv-sheet-tab"><span className="swatch"></span>Documents</button>
        <button className="pv-sheet-tab"><span className="swatch"></span>Errors · 17</button>
        <button className="pv-sheet-tab"><span className="swatch"></span>Q3 totals</button>
        <button className="pv-sheet-tab"><span className="swatch"></span>Notes</button>
        <span className="spacer"></span>
        <button className="add" aria-label="Add sheet">+</button>
      </div>

      <div className="pv-sheet-statusbar">
        <div className="stat">
          <span>Sheet</span><b>Sources</b>
          <span className="sep">·</span>
          <span>Rows</span><b>15</b>
          <span className="sep">·</span>
          <span>Cols</span><b>8</b>
        </div>
        <div className="stat">
          <span>SUM</span><b>544,273</b>
          <span className="sep">·</span>
          <span>AVG</span><b>36,285</b>
          <span className="sep">·</span>
          <span>COUNT</span><b>15</b>
        </div>
      </div>
    </div>
  );
}

window.PreviewSheet = PreviewSheet;
