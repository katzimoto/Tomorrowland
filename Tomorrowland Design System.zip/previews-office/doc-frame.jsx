/* global React, Icon */
// Shared chrome: doc-toolbar + split preview/insight body.
// Each PreviewMode (Word / Slides / Sheet) renders into the `preview` slot;
// the insight panel content is keyed by file kind via DOC_META.

const DOC_META = {
  docx: {
    fileIcon: 'DOCX',
    fileIconClass: 'docx',
    title: 'Procurement runbook · vendor onboarding & PO approval',
    source: 'Confluence · IT Knowledge Base',
    tags: ['runbook', 'procurement', 'on-call'],
    updated: 'May 21 2025',
    translation: { quality: 'high', label: 'EN' },
    pages: { current: 3, total: 12 },
    summary:
      'Single-source operations guide for vendor onboarding and purchase-order approval. Covers pre-checks, the dual-sign flow, NetSuite handoff, rollback steps, and on-call escalation for failed sync events.',
    entities: ['NetSuite', 'Coupa', 'Active Directory', 'sales-ops', 'finance-ops', 'K. Tanaka'],
    related: [
      { title: 'NetSuite — vendor record schema (v3)', src: 'Confluence', updated: '3w ago' },
      { title: 'PO escalation rota — Q3', src: 'Confluence', updated: '6d ago' },
      { title: 'AD group: finance-ops-approvers', src: 'Jira INFRA-2841', updated: '12d ago' },
    ],
  },
  pptx: {
    fileIcon: 'PPTX',
    fileIconClass: 'pptx',
    title: 'Q3 platform review — leadership readout',
    source: 'Folder · /shared/leadership/2025-q3',
    tags: ['leadership', 'quarterly', 'metrics'],
    updated: 'Jul 10 2025',
    translation: { quality: null, label: null },
    pages: { current: 4, total: 18 },
    summary:
      'Quarterly readout to the leadership group. Highlights ingestion-pipeline throughput gains, the cyber-cyan rebrand rollout, two ongoing risks (LibreTranslate latency, Confluence DC migration), and the FY26 hiring plan for the intelligence sub-team.',
    entities: ['Ingestion', 'Worker-fast', 'Worker-intelligence', 'LibreTranslate', 'Confluence DC', 'D. Park', 'M. Roussel'],
    related: [
      { title: 'Q2 platform review (preceding)', src: 'Folder', updated: 'Apr 14 2025' },
      { title: 'FY26 hiring plan — intelligence', src: 'Confluence', updated: '2d ago' },
      { title: 'INFRA-3104 · LibreTranslate p99 regression', src: 'Jira', updated: '5h ago' },
    ],
  },
  xlsx: {
    fileIcon: 'XLSX',
    fileIconClass: 'xlsx',
    title: 'Source inventory · documents indexed by source',
    source: 'Folder · /ops/reports/2025',
    tags: ['inventory', 'indexing', 'ops'],
    updated: 'Aug 14 2025',
    translation: { quality: null, label: null },
    pages: { current: null, total: null },
    summary:
      'Workbook tracking every active ingestion source, its language, document count, last successful sync, and failure state. The Errors tab carries 17 open DLQ entries; the Q3 totals tab aggregates by source type.',
    entities: ['Confluence', 'Jira', 'SMB-finance', 'SMB-legal', 'NiFi', 'Active Directory'],
    related: [
      { title: 'DLQ retry policy — runbook', src: 'Confluence', updated: '1w ago' },
      { title: 'NiFi flow — legal-share', src: 'NiFi', updated: '4h ago' },
      { title: 'INFRA-3091 · Jira DC sync stall', src: 'Jira', updated: '2d ago' },
    ],
  },
};

function DocBadgeRow({ kind }) {
  const meta = DOC_META[kind];
  return (
    <div className="ip-badge-row">
      <span className="badge source">{meta.source.split(' · ')[0]}</span>
      {meta.tags.map((t) => (
        <span key={t} className="badge tag">{t}</span>
      ))}
      {meta.translation.quality === 'high' && (
        <span className="badge translation">{meta.translation.label} · high</span>
      )}
    </div>
  );
}

function InsightPanel({ kind, activeTab = 'summary' }) {
  const meta = DOC_META[kind];
  const TABS = ['Summary', 'Q&A', 'Related', 'Annotations', 'Comments', 'Versions'];
  return (
    <aside className="doc-insight-col">
      <div className="ip-tabs">
        {TABS.map((t) => (
          <button
            key={t}
            className={`ip-tab${t.toLowerCase() === activeTab ? ' active' : ''}`}
          >
            {t}
          </button>
        ))}
      </div>
      <div className="ip-body">
        <p className="ip-lead">{meta.summary}</p>

        <div className="ip-section">
          <h3>Tags</h3>
          <DocBadgeRow kind={kind} />
        </div>

        <div className="ip-section">
          <h3>Entities</h3>
          <div className="ip-dot-list">
            {meta.entities.map((e, i) => (
              <React.Fragment key={e}>
                {i > 0 && <span className="sep">·</span>}
                <span className="item">{e}</span>
              </React.Fragment>
            ))}
          </div>
        </div>

        <div className="ip-section">
          <h3>Related documents</h3>
          {meta.related.map((r) => (
            <div key={r.title} className="ip-related-row">
              <div className="ip-related-title">{r.title}</div>
              <div className="ip-related-meta">
                <span>{r.src}</span>
                <span className="dot">·</span>
                <span>{r.updated}</span>
              </div>
            </div>
          ))}
        </div>

        <p className="ip-generated-by">Generated by mistral:7b-instruct · {meta.updated}</p>
      </div>
    </aside>
  );
}

function DocToolbar({ kind }) {
  const meta = DOC_META[kind];
  const sourceParts = meta.source.split(' · ');
  return (
    <div className="doc-toolbar">
      <button className="doc-back" aria-label="Back to search">
        <Icon name="chevron-left" size={20} />
      </button>
      <div className={`doc-file-icon ${meta.fileIconClass}`}>{meta.fileIcon}</div>
      <div className="doc-title-group">
        <h1 className="doc-title">{meta.title}</h1>
        <div className="doc-meta">
          <span className="source">{sourceParts[0]}</span>
          {sourceParts[1] && (
            <>
              <span className="dot">/</span>
              <span>{sourceParts[1]}</span>
            </>
          )}
          <span className="dot">·</span>
          <span className="tag">{meta.tags[0]}</span>
          <span className="dot">·</span>
          <span>Updated {meta.updated}</span>
        </div>
      </div>
      <div className="doc-controls">
        <button className="btn btn-ghost">
          <Icon name="messages" size={14} /> Chat about this
        </button>
        <button className="btn btn-secondary">
          <Icon name="download" size={14} /> Download
        </button>
      </div>
    </div>
  );
}

function DocFrame({ kind, children }) {
  return (
    <div className="doc-scene">
      <DocToolbar kind={kind} />
      <div className="doc-body">
        <div className="doc-preview-col">{children}</div>
        <InsightPanel kind={kind} />
      </div>
    </div>
  );
}

Object.assign(window, { DOC_META, DocFrame, DocToolbar, InsightPanel });
